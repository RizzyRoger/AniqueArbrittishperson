import { type AntiqueListing, type InsertAntiqueListing, type SearchHistory, type InsertSearchHistory, type BookmarkedItem, type InsertBookmarkedItem } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Antique Listings
  getAntiqueListing(id: string): Promise<AntiqueListing | undefined>;
  getAntiqueListings(filters?: {
    category?: string;
    minPrice?: number;
    maxPrice?: number;
    minProfit?: number;
    profitType?: string;
  }): Promise<AntiqueListing[]>;
  createAntiqueListing(listing: InsertAntiqueListing): Promise<AntiqueListing>;
  updateAntiqueListing(id: string, updates: Partial<AntiqueListing>): Promise<AntiqueListing | undefined>;
  deleteAntiqueListing(id: string): Promise<boolean>;

  // Search History
  getSearchHistory(limit?: number): Promise<SearchHistory[]>;
  createSearchHistory(search: InsertSearchHistory): Promise<SearchHistory>;

  // Bookmarks
  getBookmarkedItems(): Promise<BookmarkedItem[]>;
  createBookmark(bookmark: InsertBookmarkedItem): Promise<BookmarkedItem>;
  deleteBookmark(id: string): Promise<boolean>;
  toggleBookmark(antiqueListingId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private antiqueListings: Map<string, AntiqueListing>;
  private searchHistory: Map<string, SearchHistory>;
  private bookmarkedItems: Map<string, BookmarkedItem>;

  constructor() {
    this.antiqueListings = new Map();
    this.searchHistory = new Map();
    this.bookmarkedItems = new Map();
    
    // Add sample listings for demonstration
    this.initializeSampleData();
  }

  private async initializeSampleData() {
    const sampleListings = [
      {
        ebayItemId: "sample-1",
        title: "Vintage Royal Copenhagen Blue Fluted Full Lace Dinner Plate",
        description: "Beautiful vintage Danish porcelain dinner plate from the prestigious Royal Copenhagen Blue Fluted Full Lace series",
        currentPrice: 85.00,
        estimatedValue: 185.00,
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop",
        ebayUrl: "https://www.ebay.com/itm/sample-1",
        category: "pottery",
        condition: "Excellent",
        timeLeft: "2d 14h left",
        listingType: "auction",
        profitAmount: 100.00,
        profitPercentage: 117.6,
        confidenceScore: 73.0,
        valuationSources: ["WorthPoint", "Heritage Auctions"],
        legitimacyConfidence: 85.0,
        imageQuality: 92.0,
        legitimacyFlags: [],
        legitimacyIndicators: ["High-quality photos", "Detailed description", "Reasonable pricing"],
        legitimacyAnalysis: "High-quality listing with professional photography and comprehensive details",
        isBookmarked: false,
      },
      {
        ebayItemId: "sample-2", 
        title: "Antique Victorian Sterling Silver Tea Set - 4 Pieces",
        description: "Exquisite Victorian era sterling silver tea service including teapot, sugar bowl, creamer, and tray",
        currentPrice: 450.00,
        estimatedValue: 950.00,
        imageUrl: "https://images.unsplash.com/photo-1544441893-675973e31985?w=400&h=300&fit=crop",
        ebayUrl: "https://www.ebay.com/itm/sample-2",
        category: "silver",
        condition: "Very Good",
        timeLeft: "1d 8h left",
        listingType: "auction",
        profitAmount: 500.00,
        profitPercentage: 111.1,
        confidenceScore: 92.0,
        valuationSources: ["Artnet", "WorthPoint", "Heritage Auctions"],
        legitimacyConfidence: 78.0,
        imageQuality: 88.0,
        legitimacyFlags: ["High-value item from newer seller"],
        legitimacyIndicators: ["Multiple auction references", "Clear photos"],
        legitimacyAnalysis: "Legitimate listing but requires careful verification due to high value",
        isBookmarked: false,
      },
      {
        ebayItemId: "sample-3",
        title: "Mid-Century Modern Teak Dining Table by Arne Vodder",
        description: "Authentic 1960s Danish Modern teak dining table designed by Arne Vodder for Sibast Furniture",
        currentPrice: 1200.00,
        estimatedValue: 2400.00,
        imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=300&fit=crop",
        ebayUrl: "https://www.ebay.com/itm/sample-3",
        category: "furniture",
        condition: "Good",
        timeLeft: "6h 22m left",
        listingType: "auction",
        profitAmount: 1200.00,
        profitPercentage: 100.0,
        confidenceScore: 67.5,
        valuationSources: ["WorthPoint", "Heritage Auctions"],
        legitimacyConfidence: 72.0,
        imageQuality: 85.0,
        legitimacyFlags: [],
        legitimacyIndicators: ["Designer piece", "Good condition documentation"],
        legitimacyAnalysis: "Authentic mid-century piece with appropriate market pricing",
        isBookmarked: false,
      },
      {
        ebayItemId: "sample-4",
        title: "Art Deco Amber Glass Vase by Daum Nancy France",
        description: "Stunning 1920s Art Deco amber glass vase with etched floral design, signed Daum Nancy",
        currentPrice: 320.00,
        estimatedValue: 580.00,
        imageUrl: "https://images.unsplash.com/photo-1578116922645-3976907d4326?w=400&h=300&fit=crop",
        ebayUrl: "https://www.ebay.com/itm/sample-4",
        category: "glass",
        condition: "Excellent",
        timeLeft: "4d 12h left",
        listingType: "buy_it_now",
        profitAmount: 260.00,
        profitPercentage: 81.3,
        confidenceScore: 84.3,
        valuationSources: ["Artnet", "WorthPoint"],
        legitimacyConfidence: 90.0,
        imageQuality: 95.0,
        legitimacyFlags: [],
        legitimacyIndicators: ["Signed piece", "Professional photography", "Detailed provenance"],
        legitimacyAnalysis: "Excellent quality listing with clear authentication markers",
        isBookmarked: false,
      },
      {
        ebayItemId: "sample-5",
        title: "Antique Chinese Qing Dynasty Jade Bracelet",
        description: "Rare Qing Dynasty nephrite jade bracelet with intricate carved dragon motif, circa 1800s",
        currentPrice: 680.00,
        estimatedValue: 1350.00,
        imageUrl: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400&h=300&fit=crop",
        ebayUrl: "https://www.ebay.com/itm/sample-5",
        category: "jewelry",
        condition: "Very Good",
        timeLeft: "3d 6h left",
        listingType: "auction",
        profitAmount: 670.00,
        profitPercentage: 98.5,
        confidenceScore: 71.8,
        valuationSources: ["Heritage Auctions", "WorthPoint"],
        legitimacyConfidence: 65.0,
        imageQuality: 75.0,
        legitimacyFlags: ["Limited documentation", "High-value Asian antique"],
        legitimacyIndicators: ["Period appropriate style"],
        legitimacyAnalysis: "Requires expert authentication due to high value and limited provenance",
        isBookmarked: false,
      },
      {
        ebayItemId: "sample-6",
        title: "1920s French Art Nouveau Bronze Sculpture by Auguste Moreau",
        description: "Beautiful Art Nouveau bronze sculpture depicting a dancing maiden, signed A. Moreau",
        currentPrice: 850.00,
        estimatedValue: 1650.00,
        imageUrl: "https://images.unsplash.com/photo-1551732998-cdb61d8a4479?w=400&h=300&fit=crop",
        ebayUrl: "https://www.ebay.com/itm/sample-6",
        category: "art",
        condition: "Excellent",
        timeLeft: "5d 18h left",
        listingType: "buy_it_now",
        profitAmount: 800.00,
        profitPercentage: 94.1,
        confidenceScore: 82.0,
        legitimacyConfidence: 88.0,
        imageQuality: 91.0,
        legitimacyFlags: [],
        legitimacyIndicators: ["Artist signature visible", "Period appropriate style", "Quality photography"],
        legitimacyAnalysis: "Well-documented bronze sculpture with clear artistic attribution",
        valuationSources: ["Artnet", "Heritage Auctions", "WorthPoint"],
        isBookmarked: false,
      },
      {
        ebayItemId: "sample-7",
        title: "Vintage Meissen Porcelain Figurine - 18th Century Shepherd",
        description: "Rare 18th century Meissen porcelain figurine of a shepherd with blue crossed swords mark",
        currentPrice: 280.00,
        estimatedValue: 520.00,
        imageUrl: "https://images.unsplash.com/photo-1558618047-b93d99b28a9c?w=400&h=300&fit=crop",
        ebayUrl: "https://www.ebay.com/itm/sample-7",
        category: "collectibles",
        condition: "Very Good",
        timeLeft: "2d 4h left",
        listingType: "auction",
        profitAmount: 240.00,
        profitPercentage: 85.7,
        confidenceScore: 90.0,
        valuationSources: ["WorthPoint", "Heritage Auctions"],
        legitimacyConfidence: 82.0,
        imageQuality: 89.0,
        legitimacyFlags: [],
        legitimacyIndicators: ["Authenticated maker's mark", "Period appropriate"],
        legitimacyAnalysis: "Authentic Meissen piece with proper provenance markers",
        isBookmarked: false,
      },
      {
        ebayItemId: "sample-8",
        title: "Art Deco Waterford Crystal Decanter Set - Ireland",
        description: "Vintage Waterford crystal whiskey decanter with matching glasses, Art Deco design from Ireland",
        currentPrice: 150.00,
        estimatedValue: 275.00,
        imageUrl: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=400&h=300&fit=crop",
        ebayUrl: "https://www.ebay.com/itm/sample-8",
        category: "glass",
        condition: "Excellent",
        timeLeft: "1d 16h left",
        listingType: "buy_it_now",
        profitAmount: 125.00,
        profitPercentage: 83.3,
        confidenceScore: 76.5,
        valuationSources: ["WorthPoint", "Artnet"],
        legitimacyConfidence: 93.0,
        imageQuality: 96.0,
        legitimacyFlags: [],
        legitimacyIndicators: ["Waterford stamp visible", "Crystal clarity excellent", "Complete set"],
        legitimacyAnalysis: "Genuine Waterford crystal with excellent documentation",
        isBookmarked: false,
      }
    ];

    for (const sample of sampleListings) {
      const id = randomUUID();
      const listing: AntiqueListing = {
        ...sample,
        id,
        createdAt: new Date(),
        description: sample.description || null,
        estimatedValue: sample.estimatedValue || null,
        imageUrl: sample.imageUrl || null,
        category: sample.category || null,
        condition: sample.condition || null,
        timeLeft: sample.timeLeft || null,
        listingType: sample.listingType || null,
        profitAmount: sample.profitAmount || null,
        profitPercentage: sample.profitPercentage || null,
        confidenceScore: sample.confidenceScore || null,
        valuationSources: Array.isArray(sample.valuationSources) ? sample.valuationSources : null,
        legitimacyConfidence: sample.legitimacyConfidence || null,
        imageQuality: sample.imageQuality || null,
        legitimacyFlags: Array.isArray(sample.legitimacyFlags) ? sample.legitimacyFlags : null,
        legitimacyIndicators: Array.isArray(sample.legitimacyIndicators) ? sample.legitimacyIndicators : null,
        legitimacyAnalysis: sample.legitimacyAnalysis || null,
        isBookmarked: sample.isBookmarked || false,
      };
      this.antiqueListings.set(id, listing);
    }
  }

  async getAntiqueListing(id: string): Promise<AntiqueListing | undefined> {
    return this.antiqueListings.get(id);
  }

  async getAntiqueListings(filters?: {
    category?: string;
    minPrice?: number;
    maxPrice?: number;
    minProfit?: number;
    profitType?: string;
  }): Promise<AntiqueListing[]> {
    let listings = Array.from(this.antiqueListings.values());

    if (filters) {
      if (filters.category && filters.category !== 'all') {
        listings = listings.filter(item => item.category === filters.category);
      }
      if (filters.minPrice !== undefined) {
        listings = listings.filter(item => item.currentPrice >= filters.minPrice!);
      }
      if (filters.maxPrice !== undefined) {
        listings = listings.filter(item => item.currentPrice <= filters.maxPrice!);
      }
      if (filters.minProfit !== undefined) {
        if (filters.profitType === 'percentage') {
          listings = listings.filter(item => (item.profitPercentage || 0) >= filters.minProfit!);
        } else {
          listings = listings.filter(item => (item.profitAmount || 0) >= filters.minProfit!);
        }
      }
    }

    // Sort by profit potential (highest first)
    return listings.sort((a, b) => (b.profitAmount || 0) - (a.profitAmount || 0));
  }

  async createAntiqueListing(insertListing: InsertAntiqueListing): Promise<AntiqueListing> {
    const id = randomUUID();
    const listing: AntiqueListing = {
      ...insertListing,
      id,
      createdAt: new Date(),
      description: insertListing.description || null,
      estimatedValue: insertListing.estimatedValue || null,
      imageUrl: insertListing.imageUrl || null,
      category: insertListing.category || null,
      condition: insertListing.condition || null,
      timeLeft: insertListing.timeLeft || null,
      listingType: insertListing.listingType || null,
      profitAmount: insertListing.profitAmount || null,
      profitPercentage: insertListing.profitPercentage || null,
      confidenceScore: insertListing.confidenceScore || null,
      valuationSources: insertListing.valuationSources || null,
      isBookmarked: insertListing.isBookmarked || false,
    };
    this.antiqueListings.set(id, listing);
    return listing;
  }

  async updateAntiqueListing(id: string, updates: Partial<AntiqueListing>): Promise<AntiqueListing | undefined> {
    const existing = this.antiqueListings.get(id);
    if (!existing) return undefined;

    const updated = { ...existing, ...updates };
    this.antiqueListings.set(id, updated);
    return updated;
  }

  async deleteAntiqueListing(id: string): Promise<boolean> {
    return this.antiqueListings.delete(id);
  }

  async getSearchHistory(limit = 10): Promise<SearchHistory[]> {
    const history = Array.from(this.searchHistory.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
    return history;
  }

  async createSearchHistory(insertSearch: InsertSearchHistory): Promise<SearchHistory> {
    const id = randomUUID();
    const search: SearchHistory = {
      ...insertSearch,
      id,
      createdAt: new Date(),
      category: insertSearch.category || null,
      minPrice: insertSearch.minPrice || null,
      maxPrice: insertSearch.maxPrice || null,
      minProfit: insertSearch.minProfit || null,
      profitType: insertSearch.profitType || null,
      riskTolerance: insertSearch.riskTolerance || null,
      resultCount: insertSearch.resultCount || null,
    };
    this.searchHistory.set(id, search);
    return search;
  }

  async getBookmarkedItems(): Promise<BookmarkedItem[]> {
    return Array.from(this.bookmarkedItems.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async createBookmark(insertBookmark: InsertBookmarkedItem): Promise<BookmarkedItem> {
    const id = randomUUID();
    const bookmark: BookmarkedItem = {
      ...insertBookmark,
      id,
      createdAt: new Date(),
      notes: insertBookmark.notes || null,
    };
    this.bookmarkedItems.set(id, bookmark);
    return bookmark;
  }

  async deleteBookmark(id: string): Promise<boolean> {
    return this.bookmarkedItems.delete(id);
  }

  async toggleBookmark(antiqueListingId: string): Promise<boolean> {
    // Find existing bookmark
    const existing = Array.from(this.bookmarkedItems.values())
      .find(bookmark => bookmark.antiqueListingId === antiqueListingId);

    if (existing) {
      this.bookmarkedItems.delete(existing.id);
      
      // Update the listing's bookmark status
      const listing = Array.from(this.antiqueListings.values())
        .find(item => item.id === antiqueListingId);
      if (listing) {
        await this.updateAntiqueListing(antiqueListingId, { isBookmarked: false });
      }
      return false;
    } else {
      await this.createBookmark({ antiqueListingId });
      
      // Update the listing's bookmark status
      const listing = Array.from(this.antiqueListings.values())
        .find(item => item.id === antiqueListingId);
      if (listing) {
        await this.updateAntiqueListing(antiqueListingId, { isBookmarked: true });
      }
      return true;
    }
  }
}

export const storage = new MemStorage();
