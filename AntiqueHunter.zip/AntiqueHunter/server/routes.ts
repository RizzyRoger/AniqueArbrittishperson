import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSearchHistorySchema } from "@shared/schema";
import { analyzeLegitimacy } from "./ai-analyzer";

// eBay API configuration
const EBAY_APP_ID = process.env.EBAY_APP_ID || process.env.EBAY_CLIENT_ID || "default_app_id";
const EBAY_CERT_ID = process.env.EBAY_CERT_ID || process.env.EBAY_CLIENT_SECRET || "default_cert_id";
const EBAY_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://api.ebay.com' 
  : 'https://api.sandbox.ebay.com';

// Valuation API keys
const COMMODITIES_API_KEY = process.env.COMMODITIES_API_KEY || "demo_key";

interface EbayTokenResponse {
  access_token: string;
  expires_in: number;
  token_type: string;
}

interface EbaySearchResponse {
  itemSummaries?: Array<{
    itemId: string;
    title: string;
    price: {
      value: string;
      currency: string;
    };
    image?: {
      imageUrl: string;
    };
    itemWebUrl: string;
    condition?: string;
    categories?: Array<{
      categoryName: string;
    }>;
    itemEndDate?: string;
    buyingOptions?: string[];
  }>;
  total: number;
}

// Cache for eBay access token
let ebayAccessToken: string | null = null;
let tokenExpiry: number = 0;

async function getEbayAccessToken(): Promise<string> {
  if (ebayAccessToken && Date.now() < tokenExpiry) {
    return ebayAccessToken;
  }

  const credentials = Buffer.from(`${EBAY_APP_ID}:${EBAY_CERT_ID}`).toString('base64');
  
  try {
    const response = await fetch(`${EBAY_BASE_URL}/identity/v1/oauth2/token`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope',
    });

    if (!response.ok) {
      throw new Error(`eBay token request failed: ${response.status}`);
    }

    const data: EbayTokenResponse = await response.json();
    ebayAccessToken = data.access_token;
    tokenExpiry = Date.now() + (data.expires_in * 1000) - 60000; // Refresh 1 min early
    
    return ebayAccessToken;
  } catch (error) {
    console.error('Failed to get eBay access token:', error);
    throw new Error('Failed to authenticate with eBay API');
  }
}

async function searchEbayListings(query?: string, category?: string, minPrice?: number, maxPrice?: number, limit = 50): Promise<EbaySearchResponse> {
  const token = await getEbayAccessToken();
  
  const params = new URLSearchParams({
    q: query || 'antique vintage collectible',
    limit: limit.toString(),
  });

  if (category && category !== 'all') {
    // Map categories to eBay category IDs (simplified mapping)
    const categoryMap: Record<string, string> = {
      'furniture': '3197',
      'jewelry': '281',
      'pottery': '385',
      'art': '550',
      'collectibles': '1',
      'glass': '22648',
      'silver': '20081',
    };
    
    if (categoryMap[category]) {
      params.append('category_ids', categoryMap[category]);
    }
  }

  if (minPrice !== undefined && minPrice !== null) {
    const maxPriceValue = (maxPrice !== undefined && maxPrice !== null) ? maxPrice : '*';
    params.append('filter', `price:[${minPrice}..${maxPriceValue}],currency:USD`);
  }

  const url = `${EBAY_BASE_URL}/buy/browse/v1/item_summary/search?${params}`;

  try {
    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'X-EBAY-C-MARKETPLACE-ID': 'EBAY_US',
        'Accept': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`eBay search failed: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('eBay search error:', error);
    throw new Error('Failed to search eBay listings');
  }
}

// Mock valuation function (in production, this would integrate with actual APIs)
async function getEstimatedValue(title: string, category?: string): Promise<{
  estimatedValue: number;
  confidence: number;
  sources: string[];
}> {
  // Mock valuation logic - in production, integrate with WorthPoint, Heritage Auctions, etc.
  const baseMultiplier = Math.random() * 2 + 1; // 1-3x multiplier
  const categoryMultipliers: Record<string, number> = {
    'jewelry': 2.5,
    'art': 2.0,
    'furniture': 1.8,
    'pottery': 1.6,
    'silver': 2.2,
    'collectibles': 1.4,
    'glass': 1.5,
  };

  const multiplier = categoryMultipliers[category || 'collectibles'] || 1.5;
  const confidence = Math.random() * 40 + 50; // 50-90% confidence

  return {
    estimatedValue: 0, // Will be calculated based on current price
    confidence,
    sources: ['WorthPoint', 'Heritage Auctions', 'Artnet'],
  };
}

function calculateTimeLeft(endDate?: string): string {
  if (!endDate) return 'N/A';
  
  const now = new Date();
  const end = new Date(endDate);
  const diff = end.getTime() - now.getTime();
  
  if (diff <= 0) return 'Ended';
  
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  
  if (days > 0) return `${days}d ${hours}h left`;
  if (hours > 0) return `${hours}h ${minutes}m left`;
  return `${minutes}m left`;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Search eBay listings
  app.post("/api/search", async (req, res) => {
    try {
      const { query, category, listingType, minPrice, maxPrice, minProfit, profitType, riskTolerance } = req.body;

      // Query is now optional - browse all listings if no query provided

      // Search eBay
      const ebayResults = await searchEbayListings(query, category, minPrice, maxPrice);

      if (!ebayResults.itemSummaries) {
        return res.json({ listings: [], total: 0 });
      }

      // Process results and calculate profit potential
      const processedListings = [];

      for (const item of ebayResults.itemSummaries) {
        const currentPrice = parseFloat(item.price.value);
        const itemCategory = item.categories?.[0]?.categoryName?.toLowerCase() || category;
        
        // Get estimated value
        const valuation = await getEstimatedValue(item.title, itemCategory);
        const estimatedValue = currentPrice * (Math.random() * 2 + 1.2); // Mock estimation
        
        const profitAmount = Math.max(0, estimatedValue - currentPrice);
        const profitPercentage = currentPrice > 0 ? (profitAmount / currentPrice) * 100 : 0;
        
        // Filter based on minimum profit requirements (only if specified)
        if (minProfit !== undefined && minProfit !== null && minProfit !== '' && minProfit > 0) {
          if (profitType === 'percentage' && profitPercentage < minProfit) continue;
          if (profitType === 'dollar' && profitAmount < minProfit) continue;
        }

        // AI Analysis for legitimacy
        let legitimacyAnalysis = null;
        if (item.image?.imageUrl) {
          try {
            legitimacyAnalysis = await analyzeLegitimacy(
              item.image.imageUrl, 
              item.title, 
              '', // description not available in eBay search
              currentPrice
            );
          } catch (error) {
            console.error('AI analysis failed for item:', item.itemId, error);
          }
        }

        // Determine item listing type
        const itemListingType = item.buyingOptions?.includes('AUCTION') ? 'auction' : 'buy_it_now';
        
        // Filter by listing type - only if specified
        if (listingType && listingType !== '' && listingType !== 'all') {
          if (listingType === 'auction' && itemListingType !== 'auction') continue;
          if (listingType === 'bin' && itemListingType !== 'buy_it_now') continue;
        }

        // Filter by risk tolerance (legitimacy confidence score) - only if specified
        if (riskTolerance && riskTolerance !== '') {
          const confidenceThreshold = riskTolerance === 'conservative' ? 80 : 
                                     riskTolerance === 'moderate' ? 60 : 40;
          // Use legitimacy confidence if available, fallback to old confidence score
          const confidenceToUse = legitimacyAnalysis?.confidenceScore || valuation.confidence;
          if (confidenceToUse < confidenceThreshold) continue;
        }

        const listing = await storage.createAntiqueListing({
          ebayItemId: item.itemId,
          title: item.title,
          description: '',
          currentPrice,
          estimatedValue,
          imageUrl: item.image?.imageUrl,
          ebayUrl: item.itemWebUrl,
          category: itemCategory,
          condition: item.condition,
          timeLeft: calculateTimeLeft(item.itemEndDate),
          listingType: itemListingType,
          profitAmount,
          profitPercentage,
          confidenceScore: valuation.confidence,
          valuationSources: valuation.sources,
          legitimacyConfidence: legitimacyAnalysis?.confidenceScore || null,
          imageQuality: legitimacyAnalysis?.imageQuality || null,
          legitimacyFlags: legitimacyAnalysis?.redFlags || null,
          legitimacyIndicators: legitimacyAnalysis?.positiveIndicators || null,
          legitimacyAnalysis: legitimacyAnalysis?.analysis || null,
          isBookmarked: false,
        });

        processedListings.push(listing);
      }

      // Save search history
      await storage.createSearchHistory({
        query,
        category,
        minPrice,
        maxPrice,
        minProfit,
        profitType,
        riskTolerance,
        resultCount: processedListings.length,
      });

      res.json({
        listings: processedListings,
        total: processedListings.length,
      });

    } catch (error: any) {
      console.error('Search error:', error);
      res.status(500).json({ 
        message: error.message || "Failed to search eBay listings" 
      });
    }
  });

  // Get all listings with filters
  app.get("/api/listings", async (req, res) => {
    try {
      const { category, minPrice, maxPrice, minProfit, profitType } = req.query;
      
      const filters = {
        category: category as string,
        minPrice: minPrice ? parseFloat(minPrice as string) : undefined,
        maxPrice: maxPrice ? parseFloat(maxPrice as string) : undefined,
        minProfit: minProfit ? parseFloat(minProfit as string) : undefined,
        profitType: profitType as string,
      };

      const listings = await storage.getAntiqueListings(filters);
      res.json({ listings });
    } catch (error: any) {
      console.error('Get listings error:', error);
      res.status(500).json({ message: error.message || "Failed to get listings" });
    }
  });

  // Get search history
  app.get("/api/search-history", async (req, res) => {
    try {
      const history = await storage.getSearchHistory();
      res.json({ history });
    } catch (error: any) {
      console.error('Get search history error:', error);
      res.status(500).json({ message: error.message || "Failed to get search history" });
    }
  });

  // Toggle bookmark
  app.post("/api/bookmarks/:listingId/toggle", async (req, res) => {
    try {
      const { listingId } = req.params;
      const isBookmarked = await storage.toggleBookmark(listingId);
      res.json({ isBookmarked });
    } catch (error: any) {
      console.error('Toggle bookmark error:', error);
      res.status(500).json({ message: error.message || "Failed to toggle bookmark" });
    }
  });

  // Get bookmarked items
  app.get("/api/bookmarks", async (req, res) => {
    try {
      const bookmarks = await storage.getBookmarkedItems();
      res.json({ bookmarks });
    } catch (error: any) {
      console.error('Get bookmarks error:', error);
      res.status(500).json({ message: error.message || "Failed to get bookmarks" });
    }
  });

  // Export listings
  app.get("/api/export", async (req, res) => {
    try {
      const { format = 'json' } = req.query;
      const listings = await storage.getAntiqueListings();

      if (format === 'csv') {
        const csv = [
          'Title,Current Price,Estimated Value,Profit Amount,Profit Percentage,Confidence,eBay URL',
          ...listings.map(item => [
            `"${item.title}"`,
            item.currentPrice,
            item.estimatedValue || '',
            item.profitAmount || '',
            item.profitPercentage || '',
            item.confidenceScore || '',
            `"${item.ebayUrl}"`
          ].join(','))
        ].join('\n');

        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=antique-listings.csv');
        res.send(csv);
      } else {
        res.json({ listings });
      }
    } catch (error: any) {
      console.error('Export error:', error);
      res.status(500).json({ message: error.message || "Failed to export listings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
