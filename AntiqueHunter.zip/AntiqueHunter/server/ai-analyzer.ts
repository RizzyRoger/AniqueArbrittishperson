import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface LegitimacyAnalysis {
  confidenceScore: number; // 0-100 percentage
  imageQuality: number; // 0-100 rating
  redFlags: string[];
  positiveIndicators: string[];
  analysis: string;
}

export async function analyzeLegitimacy(imageUrl: string, title: string, description: string, price: number): Promise<LegitimacyAnalysis> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are an expert antique authenticator and fraud detection specialist. Analyze eBay listings to determine legitimacy based on image quality, item description, and pricing. Consider factors like:

IMAGE QUALITY INDICATORS:
- Photo clarity, lighting, and resolution
- Multiple angles and detailed shots
- Professional vs amateur photography
- Stock photos vs authentic item photos
- Image consistency and authenticity

LEGITIMACY RED FLAGS:
- Extremely low prices for valuable items
- Poor image quality or suspicious photos
- Vague or copied descriptions
- New seller with high-value items
- Stock photos instead of actual item photos
- Inconsistent details between image and description

POSITIVE INDICATORS:
- High-quality, detailed photographs
- Comprehensive item descriptions
- Reasonable pricing for the item type
- Multiple photos from different angles
- Clear provenance or authentication details
- Seller reputation and history

Respond with JSON in this exact format:
{
  "confidenceScore": number (0-100),
  "imageQuality": number (0-100),
  "redFlags": ["flag1", "flag2"],
  "positiveIndicators": ["indicator1", "indicator2"],
  "analysis": "brief explanation"
}`
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Analyze this antique listing for legitimacy:
Title: ${title}
Description: ${description}
Price: $${price}

Please evaluate the image quality and overall legitimacy of this listing.`
            },
            {
              type: "image_url",
              image_url: {
                url: imageUrl
              }
            }
          ]
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');

    return {
      confidenceScore: Math.max(0, Math.min(100, Math.round(result.confidenceScore))),
      imageQuality: Math.max(0, Math.min(100, Math.round(result.imageQuality))),
      redFlags: Array.isArray(result.redFlags) ? result.redFlags : [],
      positiveIndicators: Array.isArray(result.positiveIndicators) ? result.positiveIndicators : [],
      analysis: result.analysis || "Analysis completed"
    };
  } catch (error) {
    console.error("AI analysis failed:", error);
    // Return a neutral score if AI analysis fails
    return {
      confidenceScore: 50,
      imageQuality: 50,
      redFlags: ["AI analysis unavailable"],
      positiveIndicators: [],
      analysis: "Unable to perform AI analysis"
    };
  }
}