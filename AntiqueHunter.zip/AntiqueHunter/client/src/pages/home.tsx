import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { AntiqueListing } from "@shared/schema";
import SearchSidebar from "@/components/search-sidebar";
import ResultsGrid from "@/components/results-grid";
import { useToast } from "@/hooks/use-toast";

interface SearchConfig {
  query: string;
  category: string;
  listingType: string;
  minPrice: string;
  maxPrice: string;
  profitType: 'dollar' | 'percentage';
  minProfit: string;
  riskTolerance: string;
}

export default function Home() {
  const [searchConfig, setSearchConfig] = useState<SearchConfig | null>(null);
  const { toast } = useToast();

  // Query for all available listings (loads immediately on page load)
  const { data: allListingsResults, isLoading: isLoadingAll, error: allListingsError } = useQuery({
    queryKey: ["/api/listings"],
    queryFn: async () => {
      const response = await fetch(`/api/listings`);
      if (!response.ok) {
        throw new Error('Failed to fetch listings');
      }
      return response.json();
    },
  });

  // Query for filtered listings based on search config
  const { data: searchResults, isLoading: isLoadingSearch, error: searchError } = useQuery({
    queryKey: ["/api/listings", searchConfig],
    enabled: !!searchConfig,
    queryFn: async () => {
      if (!searchConfig) return { listings: [] };
      
      const params = new URLSearchParams();
      if (searchConfig.category !== 'all') params.append('category', searchConfig.category);
      if (searchConfig.minPrice) params.append('minPrice', searchConfig.minPrice);
      if (searchConfig.maxPrice) params.append('maxPrice', searchConfig.maxPrice);
      if (searchConfig.minProfit) params.append('minProfit', searchConfig.minProfit);
      if (searchConfig.profitType) params.append('profitType', searchConfig.profitType);

      const response = await fetch(`/api/listings?${params}`);
      if (!response.ok) {
        throw new Error('Failed to fetch listings');
      }
      return response.json();
    },
  });

  // Mutation for performing new searches
  const searchMutation = useMutation({
    mutationFn: async (config: SearchConfig) => {
      const response = await apiRequest("POST", "/api/search", {
        query: config.query,
        category: config.category === 'all' ? undefined : config.category,
        listingType: config.listingType === 'all' ? undefined : config.listingType,
        minPrice: config.minPrice && config.minPrice.trim() ? parseFloat(config.minPrice) : undefined,
        maxPrice: config.maxPrice && config.maxPrice.trim() ? parseFloat(config.maxPrice) : undefined,
        minProfit: config.minProfit && config.minProfit.trim() ? parseFloat(config.minProfit) : undefined,
        profitType: config.profitType,
        riskTolerance: config.riskTolerance === 'moderate' ? undefined : config.riskTolerance,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Search completed",
        description: `Found ${data.listings.length} potential opportunities`,
      });
      // Refresh the listings query to show new results
      setSearchConfig(prev => ({ ...prev! }));
    },
    onError: (error: any) => {
      toast({
        title: "Search failed",
        description: error.message || "Failed to search eBay listings",
        variant: "destructive",
      });
    },
  });

  const handleSearch = (config: SearchConfig) => {
    setSearchConfig(config);
    searchMutation.mutate(config);
  };

  const handleExport = async (format: 'json' | 'csv') => {
    try {
      const response = await fetch(`/api/export?format=${format}`);
      
      if (!response.ok) {
        throw new Error('Export failed');
      }

      const filename = format === 'csv' ? 'antique-listings.csv' : 'antique-listings.json';
      
      if (format === 'csv') {
        const text = await response.text();
        const blob = new Blob([text], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } else {
        const data = await response.json();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }

      toast({
        title: "Export successful",
        description: `Downloaded ${filename}`,
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Failed to export listings",
        variant: "destructive",
      });
    }
  };

  // Show error state
  if (allListingsError && !searchConfig) {
    return (
      <div className="flex min-h-screen">
        <SearchSidebar 
          onSearch={handleSearch} 
          isLoading={searchMutation.isPending}
        />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <p className="text-destructive mb-4">Failed to load antique listings</p>
            <p className="text-sm text-muted-foreground">
              {allListingsError instanceof Error ? allListingsError.message : 'Unknown error occurred'}
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Use search results if a search has been performed, otherwise show all listings
  const listings = searchConfig ? (searchResults?.listings || []) : (allListingsResults?.listings || []);
  const isLoading = searchConfig ? (isLoadingSearch || searchMutation.isPending) : (isLoadingAll || searchMutation.isPending);

  return (
    <div className="flex flex-col md:flex-row min-h-screen" data-testid="home-page">
      <SearchSidebar 
        onSearch={handleSearch} 
        isLoading={searchMutation.isPending}
      />
      <ResultsGrid 
        listings={listings}
        isLoading={isLoading}
        onExport={handleExport}
      />
    </div>
  );
}
