import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bookmark, ExternalLink, Shield, ShieldCheck, ShieldAlert } from "lucide-react";
import { AntiqueListing } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface AntiqueCardProps {
  listing: AntiqueListing;
  viewMode?: 'grid' | 'list';
}

export default function AntiqueCard({ listing, viewMode = 'grid' }: AntiqueCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const toggleBookmarkMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/bookmarks/${listing.id}/toggle`);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/listings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
      toast({
        title: data.isBookmarked ? "Added to bookmarks" : "Removed from bookmarks",
        description: listing.title,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to toggle bookmark",
        variant: "destructive",
      });
    },
  });

  const getProfitBadgeClass = () => {
    const profit = listing.profitAmount || 0;
    const percentage = listing.profitPercentage || 0;
    
    if (profit >= 200 || percentage >= 100) {
      return "bg-gradient-to-r from-green-600 to-green-700 text-white";
    }
    if (profit >= 50 || percentage >= 50) {
      return "bg-gradient-to-r from-yellow-500 to-yellow-600 text-white";
    }
    return "bg-gradient-to-r from-gray-500 to-gray-600 text-white";
  };

  const getProfitLabel = () => {
    const profit = listing.profitAmount || 0;
    const percentage = listing.profitPercentage || 0;
    
    if (profit >= 200 || percentage >= 100) return "High Profit";
    if (profit >= 50 || percentage >= 50) return "Medium Profit";
    return "Low Profit";
  };


  const getLegitimacyTrustIndicator = () => {
    const legitimacy = listing.legitimacyConfidence || 0;
    
    if (legitimacy >= 80) {
      return {
        icon: ShieldCheck,
        color: "text-green-600 dark:text-green-400",
        bgColor: "bg-green-50 dark:bg-green-900/20",
        label: "Trusted",
        score: legitimacy
      };
    }
    if (legitimacy >= 60) {
      return {
        icon: Shield,
        color: "text-yellow-600 dark:text-yellow-400",
        bgColor: "bg-yellow-50 dark:bg-yellow-900/20",
        label: "Caution",
        score: legitimacy
      };
    }
    return {
      icon: ShieldAlert,
      color: "text-red-600 dark:text-red-400",
      bgColor: "bg-red-50 dark:bg-red-900/20",
      label: "Review",
      score: legitimacy
    };
  };

  if (viewMode === 'list') {
    return (
      <Card className="overflow-hidden shadow-sm hover:shadow-md transition-shadow">
        <div className="flex">
          <div className="relative flex-shrink-0 w-48">
            <img
              src={listing.imageUrl || "/placeholder-antique.jpg"}
              alt={listing.title}
              className="w-full h-32 object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "/api/placeholder/400/300?text=No+Image";
              }}
            />
            <div className="absolute top-1 right-1">
              <Badge className={getProfitBadgeClass()} data-testid="profit-badge">
                {getProfitLabel()}
              </Badge>
            </div>
            <div className="absolute top-1 left-1">
              <Badge variant="secondary" className="bg-black/70 text-white text-xs">
                {listing.timeLeft || 'N/A'}
              </Badge>
            </div>
          </div>

          <div className="flex-1 p-2 xs:p-3 sm:p-4">
            <div className="mb-1">
              <Badge variant="outline" className={cn(
                "text-[10px] xs:text-xs font-medium",
                listing.listingType === 'auction' ? 'border-orange-600 text-orange-600 dark:border-orange-400 dark:text-orange-400' : 'border-green-600 text-green-600 dark:border-green-400 dark:text-green-400'
              )}>
                {listing.listingType === 'auction' ? 'Auction' : 'BIN'}
              </Badge>
            </div>
            <h3 className="font-semibold text-foreground mb-2 text-xs xs:text-sm md:text-base line-clamp-2" data-testid="listing-title">
              {listing.title}
            </h3>

            <div className="space-y-2">
              <div className="grid grid-cols-2 xs:grid-cols-3 gap-2 xs:gap-3">
                <div>
                  <span className="text-[10px] xs:text-xs text-muted-foreground block truncate">Current Price</span>
                  <p className="text-xs xs:text-sm md:text-base font-bold text-foreground" data-testid="current-price">
                    ${listing.currentPrice.toFixed(2)}
                  </p>
                </div>
                <div>
                  <span className="text-[10px] xs:text-xs text-muted-foreground block truncate">Est. Value</span>
                  <p className="text-xs xs:text-sm md:text-base font-bold text-accent" data-testid="estimated-value">
                    ${(listing.estimatedValue || 0).toFixed(2)}
                  </p>
                </div>
                <div className="col-span-2 xs:col-span-1">
                  <span className="text-[10px] xs:text-xs text-muted-foreground block truncate">Profit</span>
                  <p 
                    className={cn(
                      "text-xs xs:text-sm md:text-base font-bold",
                      (listing.profitAmount || 0) >= 200 ? "text-primary" : 
                      (listing.profitAmount || 0) >= 50 ? "text-accent" : "text-muted-foreground"
                    )}
                    data-testid="profit-amount"
                  >
                    +${(listing.profitAmount || 0).toFixed(2)}
                  </p>
                </div>
              </div>

              {listing.legitimacyConfidence !== undefined && (() => {
                const trustIndicator = getLegitimacyTrustIndicator();
                const IconComponent = trustIndicator.icon;
                return (
                  <div className="flex items-center gap-1 mb-2">
                    <span className="text-[10px] xs:text-xs text-muted-foreground whitespace-nowrap">Confidence:</span>
                    <div className={cn("flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] xs:text-xs font-medium", trustIndicator.bgColor)} data-testid="confidence-indicator">
                      <IconComponent className={cn("w-3 h-3", trustIndicator.color)} />
                      <span className={trustIndicator.color}>{trustIndicator.label}</span>
                      <span className="text-muted-foreground">({Math.round(trustIndicator.score)}%)</span>
                    </div>
                  </div>
                );
              })()}
              <div className="flex justify-end">
                <Button 
                  asChild
                  size="sm"
                  data-testid="view-ebay-button"
                  className="flex-shrink-0 text-[10px] xs:text-xs"
                >
                  <a 
                    href={listing.ebayUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-center"
                  >
                    <ExternalLink className="w-3 h-3 xs:w-4 xs:h-4 mr-1" />
                    <span className="hidden xs:inline">eBay</span>
                    <span className="xs:hidden">→</span>
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="relative">
        <img
          src={listing.imageUrl || "/placeholder-antique.jpg"}
          alt={listing.title}
          className="w-full h-48 object-cover"
          onError={(e) => {
            (e.target as HTMLImageElement).src = "/api/placeholder/400/300?text=No+Image";
          }}
        />
        <div className="absolute top-2 right-2">
          <Badge className={getProfitBadgeClass()} data-testid="profit-badge">
            {getProfitLabel()}
          </Badge>
        </div>
        <div className="absolute top-2 left-2">
          <Badge variant="secondary" className="bg-black/70 text-white">
            {listing.timeLeft || 'N/A'}
          </Badge>
        </div>
      </div>

      <div className="p-2 xs:p-3 sm:p-4">
        <div className="mb-2">
          <Badge variant="outline" className={cn(
            "text-[10px] xs:text-xs font-medium",
            listing.listingType === 'auction' ? 'border-orange-600 text-orange-600 dark:border-orange-400 dark:text-orange-400' : 'border-green-600 text-green-600 dark:border-green-400 dark:text-green-400'
          )}>
            {listing.listingType === 'auction' ? 'Auction' : 'BIN'}
          </Badge>
        </div>
        <h3 className="font-semibold text-foreground mb-3 line-clamp-2 text-xs xs:text-sm sm:text-base" data-testid="listing-title">
          {listing.title}
        </h3>

        <div className="flex items-center justify-between mb-3">
          <div>
            <span className="text-[10px] xs:text-xs sm:text-sm text-muted-foreground">Current Price</span>
            <p className="text-sm xs:text-base sm:text-lg font-bold text-foreground" data-testid="current-price">
              ${listing.currentPrice.toFixed(2)}
            </p>
          </div>
          <div className="text-right">
            <span className="text-[10px] xs:text-xs sm:text-sm text-muted-foreground">Est. Value</span>
            <p className="text-sm xs:text-base sm:text-lg font-bold text-accent" data-testid="estimated-value">
              ${(listing.estimatedValue || 0).toFixed(2)}
            </p>
          </div>
        </div>

        <div className="space-y-1 sm:space-y-2 mb-4">
          <div className="flex justify-between items-center text-[10px] xs:text-xs sm:text-sm">
            <span className="text-muted-foreground truncate mr-1">Profit:</span>
            <span 
              className={cn(
                "font-semibold text-right",
                (listing.profitAmount || 0) >= 200 ? "text-primary" : 
                (listing.profitAmount || 0) >= 50 ? "text-accent" : "text-muted-foreground"
              )}
              data-testid="profit-amount"
            >
              +${(listing.profitAmount || 0).toFixed(2)} ({Math.round(listing.profitPercentage || 0)}%)
            </span>
          </div>
          {listing.legitimacyConfidence !== undefined && (() => {
            const trustIndicator = getLegitimacyTrustIndicator();
            const IconComponent = trustIndicator.icon;
            return (
              <div className="flex justify-between items-center text-[10px] xs:text-xs sm:text-sm">
                <span className="text-muted-foreground truncate mr-1">Confidence:</span>
                <div className={cn("flex items-center gap-1 px-2 py-1 rounded-md font-medium", trustIndicator.bgColor)} data-testid="confidence-indicator">
                  <IconComponent className={cn("w-3 h-3", trustIndicator.color)} />
                  <span className={trustIndicator.color}>{trustIndicator.label}</span>
                  <span className="text-muted-foreground">({Math.round(trustIndicator.score)}%)</span>
                </div>
              </div>
            );
          })()}
          <div className="flex justify-between items-center text-[10px] xs:text-xs sm:text-sm">
            <span className="text-muted-foreground truncate mr-1">Source:</span>
            <span className="font-medium text-foreground text-right truncate max-w-[60%]">
              {listing.valuationSources?.join(' + ') || 'Unknown'}
            </span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button 
            asChild
            className="flex-1"
            size="sm"
            data-testid="view-ebay-button"
          >
            <a 
              href={listing.ebayUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center justify-center"
            >
              <ExternalLink className="w-4 h-4 mr-1 sm:mr-2" />
              <span className="hidden sm:inline">View on eBay</span>
              <span className="sm:hidden">eBay</span>
            </a>
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => toggleBookmarkMutation.mutate()}
            disabled={toggleBookmarkMutation.isPending}
            data-testid="bookmark-button"
            className="w-8 h-8 sm:w-10 sm:h-10 p-1"
          >
            <Bookmark 
              className={cn(
                "w-4 h-4",
                listing.isBookmarked ? "fill-current" : ""
              )}
            />
          </Button>
        </div>
      </div>
    </Card>
  );
}
