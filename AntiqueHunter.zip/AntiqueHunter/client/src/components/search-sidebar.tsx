import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Gem, Search } from "lucide-react";
import { useState } from "react";

interface SearchConfig {
  query: string;
  category: string;
  listingType: string;
  minPrice: string;
  maxPrice: string;
  profitType: 'dollar' | 'percentage';
  minProfit: string;
  riskTolerance: string;
}

interface SearchSidebarProps {
  onSearch: (config: SearchConfig) => void;
  isLoading: boolean;
}

export default function SearchSidebar({ onSearch, isLoading }: SearchSidebarProps) {
  const [searchConfig, setSearchConfig] = useState<SearchConfig>({
    query: '',
    category: 'all',
    listingType: 'all',
    minPrice: '',
    maxPrice: '',
    profitType: 'dollar',
    minProfit: '',
    riskTolerance: '',
  });

  const handleInputChange = (field: keyof SearchConfig, value: string) => {
    setSearchConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchConfig);
  };

  return (
    <div className="w-full sm:w-72 md:w-80 lg:w-80 bg-card border-r border-border flex flex-col">
      {/* Header */}
      <div className="p-4 sm:p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Gem className="text-primary-foreground text-xl" />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-bold text-foreground">AntiqueArb</h1>
            <p className="text-xs sm:text-sm text-muted-foreground">eBay Arbitrage Tool</p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col flex-1">
        {/* Search Configuration */}
        <div className="p-4 sm:p-6 border-b border-border">
          <h2 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4 text-foreground">Search Configuration</h2>
          
          {/* Search Query */}
          <div className="mb-3 sm:mb-4">
            <Label htmlFor="search-query" className="text-xs sm:text-sm font-medium text-foreground mb-2 block">
              Search Query
            </Label>
            <Input
              id="search-query"
              type="text"
              placeholder="e.g., vintage pottery, antique jewelry"
              value={searchConfig.query}
              onChange={(e) => handleInputChange('query', e.target.value)}
              data-testid="input-search-query"
            />
          </div>

          {/* Category Filter */}
          <div className="mb-3 sm:mb-4">
            <Label htmlFor="category" className="text-sm font-medium text-foreground mb-2 block">
              Category
            </Label>
            <Select value={searchConfig.category} onValueChange={(value) => handleInputChange('category', value)}>
              <SelectTrigger data-testid="select-category">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="furniture">Furniture</SelectItem>
                <SelectItem value="jewelry">Jewelry & Watches</SelectItem>
                <SelectItem value="pottery">Pottery & Ceramics</SelectItem>
                <SelectItem value="art">Art & Paintings</SelectItem>
                <SelectItem value="collectibles">Collectibles</SelectItem>
                <SelectItem value="glass">Glass & Crystal</SelectItem>
                <SelectItem value="silver">Silver & Metalware</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Listing Type Filter */}
          <div className="mb-3 sm:mb-4">
            <Label className="text-sm font-medium text-foreground mb-2 block">
              Listing Type
            </Label>
            <div className="flex space-x-2">
              <Button
                type="button"
                variant={searchConfig.listingType === 'all' ? 'default' : 'secondary'}
                className="flex-1 text-xs sm:text-sm"
                onClick={() => handleInputChange('listingType', 'all')}
                data-testid="button-listing-all"
              >
                All
              </Button>
              <Button
                type="button"
                variant={searchConfig.listingType === 'auction' ? 'default' : 'secondary'}
                className="flex-1 text-xs sm:text-sm"
                onClick={() => handleInputChange('listingType', 'auction')}
                data-testid="button-listing-auction"
              >
                Auction
              </Button>
              <Button
                type="button"
                variant={searchConfig.listingType === 'bin' ? 'default' : 'secondary'}
                className="flex-1 text-xs sm:text-sm"
                onClick={() => handleInputChange('listingType', 'bin')}
                data-testid="button-listing-bin"
              >
                Buy It Now
              </Button>
            </div>
          </div>

          {/* Price Range */}
          <div className="mb-3 sm:mb-4">
            <Label className="text-sm font-medium text-foreground mb-2 block">Price Range</Label>
            <div className="flex space-x-2">
              <Input
                type="number"
                placeholder="Min $"
                value={searchConfig.minPrice}
                onChange={(e) => handleInputChange('minPrice', e.target.value)}
                data-testid="input-min-price"
              />
              <Input
                type="number"
                placeholder="Max $"
                value={searchConfig.maxPrice}
                onChange={(e) => handleInputChange('maxPrice', e.target.value)}
                data-testid="input-max-price"
              />
            </div>
          </div>
        </div>

        {/* Profit Settings */}
        <div className="p-4 sm:p-6 border-b border-border">
          <h2 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4 text-foreground">Profit Settings</h2>
          
          {/* Minimum Profit Type */}
          <div className="mb-3 sm:mb-4">
            <Label className="text-sm font-medium text-foreground mb-2 block">Profit Type</Label>
            <div className="flex space-x-2">
              <Button
                type="button"
                variant={searchConfig.profitType === 'dollar' ? 'default' : 'secondary'}
                className="flex-1"
                onClick={() => handleInputChange('profitType', 'dollar')}
                data-testid="button-profit-dollar"
              >
                Dollar Amount
              </Button>
              <Button
                type="button"
                variant={searchConfig.profitType === 'percentage' ? 'default' : 'secondary'}
                className="flex-1"
                onClick={() => handleInputChange('profitType', 'percentage')}
                data-testid="button-profit-percentage"
              >
                Percentage
              </Button>
            </div>
          </div>

          {/* Minimum Profit Value */}
          <div className="mb-3 sm:mb-4">
            <Label htmlFor="min-profit" className="text-sm font-medium text-foreground mb-2 block">
              Minimum Profit
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-2 text-muted-foreground">
                {searchConfig.profitType === 'dollar' ? '$' : '%'}
              </span>
              <Input
                id="min-profit"
                type="number"
                placeholder={searchConfig.profitType === 'dollar' ? '50' : '25'}
                value={searchConfig.minProfit}
                onChange={(e) => handleInputChange('minProfit', e.target.value)}
                className="pl-8"
                data-testid="input-min-profit"
              />
            </div>
          </div>

          {/* Risk Tolerance */}
          <div className="mb-3 sm:mb-4">
            <Label htmlFor="risk-tolerance" className="text-sm font-medium text-foreground mb-2 block">
              Risk Tolerance
            </Label>
            <Select value={searchConfig.riskTolerance} onValueChange={(value) => handleInputChange('riskTolerance', value)}>
              <SelectTrigger data-testid="select-risk-tolerance">
                <SelectValue placeholder="Any risk level (optional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="conservative">Conservative (High confidence)</SelectItem>
                <SelectItem value="moderate">Moderate (Medium confidence)</SelectItem>
                <SelectItem value="aggressive">Aggressive (Low confidence)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {/* Search Button */}
          <div className="mt-4">
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading}
              data-testid="button-search"
            >
              <Search className="w-4 h-4 mr-2" />
              {isLoading ? 'Searching...' : 'Search eBay Listings'}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
