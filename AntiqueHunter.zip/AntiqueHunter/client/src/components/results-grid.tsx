import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Download, Grid, List } from "lucide-react";
import { AntiqueListing } from "@shared/schema";
import AntiqueCard from "./antique-card";
import { useState } from "react";

interface ResultsGridProps {
  listings: AntiqueListing[];
  isLoading: boolean;
  onExport: (format: 'json' | 'csv') => void;
}

export default function ResultsGrid({ listings, isLoading, onExport }: ResultsGridProps) {
  const [sortBy, setSortBy] = useState('profit');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const sortedListings = [...listings].sort((a, b) => {
    switch (sortBy) {
      case 'profit':
        return (b.profitAmount || 0) - (a.profitAmount || 0);
      case 'price-low':
        return a.currentPrice - b.currentPrice;
      case 'price-high':
        return b.currentPrice - a.currentPrice;
      case 'confidence':
        return (b.confidenceScore || 0) - (a.confidenceScore || 0);
      case 'ending':
        // Sort by time left (approximate - would need proper parsing)
        return (a.timeLeft || '').localeCompare(b.timeLeft || '');
      default:
        return 0;
    }
  });

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col">
        <div className="bg-card border-b border-border px-6 py-4">
          <h2 className="text-xl font-semibold text-foreground">Searching...</h2>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Searching eBay for antique opportunities...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Top Bar */}
      <div className="bg-card border-b border-border px-3 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0">
        <div className="flex items-center space-x-2 sm:space-x-4">
          <h2 className="text-lg sm:text-xl font-semibold text-foreground">Search Results</h2>
          <Badge variant="secondary" data-testid="result-count" className="text-xs sm:text-sm">
            {listings.length} items
          </Badge>
        </div>
        
        <div className="flex items-center space-x-2 sm:space-x-3 w-full sm:w-auto overflow-x-auto">
          {/* Sort Dropdown */}
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-36 sm:w-48 text-xs sm:text-sm" data-testid="select-sort">
              <SelectValue placeholder="Sort by..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="profit">Sort by Profit Potential</SelectItem>
              <SelectItem value="price-low">Sort by Price (Low to High)</SelectItem>
              <SelectItem value="price-high">Sort by Price (High to Low)</SelectItem>
              <SelectItem value="confidence">Sort by Confidence Level</SelectItem>
              <SelectItem value="ending">Sort by Ending Soonest</SelectItem>
            </SelectContent>
          </Select>
          
          {/* View Toggle */}
          <div className="flex border border-input rounded-md">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="sm"
              className="rounded-r-none"
              onClick={() => setViewMode('grid')}
              data-testid="button-grid-view"
            >
              <Grid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              className="rounded-l-none"
              onClick={() => setViewMode('list')}
              data-testid="button-list-view"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>

          {/* Export Dropdown */}
          <Select onValueChange={(format) => onExport(format as 'json' | 'csv')}>
            <SelectTrigger className="w-24 sm:w-32 text-xs sm:text-sm" data-testid="select-export">
              <SelectValue placeholder="Export" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="json">Export JSON</SelectItem>
              <SelectItem value="csv">Export CSV</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Results Grid/List */}
      <div className="flex-1 overflow-auto p-3 sm:p-4 md:p-6">
        {listings.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">No antique listings found matching your criteria.</p>
            <p className="text-sm text-muted-foreground">
              Try adjusting your search query, profit thresholds, or risk tolerance settings.
            </p>
          </div>
        ) : (
          <div className={
            viewMode === 'grid' 
              ? "grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6"
              : "space-y-3 sm:space-y-4"
          }>
            {sortedListings.map((listing) => (
              <AntiqueCard key={listing.id} listing={listing} viewMode={viewMode} />
            ))}
          </div>
        )}

        {/* Load More Button - placeholder for pagination */}
        {listings.length > 0 && (
          <div className="mt-8 text-center">
            <Button variant="secondary" disabled data-testid="button-load-more">
              Load More Results
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
