import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const antiqueListings = pgTable("antique_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ebayItemId: text("ebay_item_id").notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  currentPrice: real("current_price").notNull(),
  estimatedValue: real("estimated_value"),
  imageUrl: text("image_url"),
  ebayUrl: text("ebay_url").notNull(),
  category: text("category"),
  condition: text("condition"),
  timeLeft: text("time_left"),
  listingType: text("listing_type"), // "auction" | "buy_it_now"
  profitAmount: real("profit_amount"),
  profitPercentage: real("profit_percentage"),
  confidenceScore: real("confidence_score"),
  valuationSources: jsonb("valuation_sources").$type<string[]>(),
  legitimacyConfidence: real("legitimacy_confidence"), // 0-100 AI confidence score
  imageQuality: real("image_quality"), // 0-100 image quality rating
  legitimacyFlags: jsonb("legitimacy_flags").$type<string[]>(), // red flags found
  legitimacyIndicators: jsonb("legitimacy_indicators").$type<string[]>(), // positive indicators
  legitimacyAnalysis: text("legitimacy_analysis"), // AI analysis summary
  isBookmarked: boolean("is_bookmarked").default(false),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const searchHistory = pgTable("search_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  query: text("query").notNull(),
  category: text("category"),
  minPrice: real("min_price"),
  maxPrice: real("max_price"),
  minProfit: real("min_profit"),
  profitType: text("profit_type"), // "dollar" | "percentage"
  riskTolerance: text("risk_tolerance"), // "conservative" | "moderate" | "aggressive"
  resultCount: integer("result_count"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const bookmarkedItems = pgTable("bookmarked_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  antiqueListingId: text("antique_listing_id").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const insertAntiqueListingSchema = createInsertSchema(antiqueListings).omit({
  id: true,
  createdAt: true,
});

export const insertSearchHistorySchema = createInsertSchema(searchHistory).omit({
  id: true,
  createdAt: true,
});

export const insertBookmarkedItemSchema = createInsertSchema(bookmarkedItems).omit({
  id: true,
  createdAt: true,
});

export type InsertAntiqueListing = z.infer<typeof insertAntiqueListingSchema>;
export type AntiqueListing = typeof antiqueListings.$inferSelect;

export type InsertSearchHistory = z.infer<typeof insertSearchHistorySchema>;
export type SearchHistory = typeof searchHistory.$inferSelect;

export type InsertBookmarkedItem = z.infer<typeof insertBookmarkedItemSchema>;
export type BookmarkedItem = typeof bookmarkedItems.$inferSelect;
