# Overview

This is a full-stack antique listing application that helps users find profitable antique opportunities on eBay. The application searches eBay listings, estimates item values using external APIs, calculates potential profit margins, and presents results in an intuitive interface. Users can bookmark interesting items, track search history, and export results for further analysis.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client uses React with TypeScript in a modern single-page application setup. The UI is built with shadcn/ui components (based on Radix UI primitives) and styled with Tailwind CSS. The application uses Wouter for client-side routing and TanStack Query for server state management. The design system follows a "new-york" style theme with customizable CSS variables for colors and spacing.

## Backend Architecture
The server is built with Express.js and TypeScript, following a RESTful API design. The application uses a layered architecture with separate concerns:
- Route handlers in `/server/routes.ts` manage API endpoints
- Storage abstraction layer in `/server/storage.ts` provides database operations
- Vite integration for development with HMR and production builds

The server handles eBay API integration for searching listings, valuation API calls for price estimation, and CRUD operations for user data.

## Database Schema
The application uses PostgreSQL with Drizzle ORM for type-safe database operations. The schema includes:
- `antique_listings`: Stores eBay item data with profit calculations and valuations
- `search_history`: Tracks user search queries and parameters
- `bookmarked_items`: Manages user bookmarks with optional notes

Database migrations are handled through Drizzle Kit with schema definitions in `/shared/schema.ts`.

## Authentication and Authorization
The current implementation appears to use session-based authentication, evidenced by the `connect-pg-simple` dependency for PostgreSQL session storage. The system includes middleware for request logging and error handling.

## External Service Integrations

### eBay API Integration
- Uses eBay Finding API for item searches
- Implements OAuth 2.0 client credentials flow for authentication
- Supports both sandbox and production environments
- Caches access tokens to minimize API calls
- Handles rate limiting and error responses

### Valuation Services
- Integrates with Commodities API for price estimation
- Supports multiple valuation sources for confidence scoring
- Implements fallback mechanisms for service unavailability

### Development Tools
- Replit integration for development environment
- Vite for fast development and optimized production builds
- TypeScript for type safety across the full stack

## Design Patterns
The application follows several key patterns:
- **Repository Pattern**: Storage abstraction allows switching between in-memory and database implementations
- **API Client Pattern**: Centralized API request handling with error management
- **Component Composition**: UI built with reusable, composable components
- **Type Safety**: Shared TypeScript types between frontend and backend via `/shared` directory